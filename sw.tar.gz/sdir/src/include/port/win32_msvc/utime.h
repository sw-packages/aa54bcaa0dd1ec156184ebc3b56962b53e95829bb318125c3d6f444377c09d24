/* src/include/port/win32_msvc/utime.h */

#include <sys/utime.h>			/* for non-unicode version */
